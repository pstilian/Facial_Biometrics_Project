this code will change the original size of you pictues,you should use a copy of your pictures to try it !!!!!
this code will change the original size of you pictues,you should use a copy of your pictures to try it !!!!!
this code will change the original size of you pictues,you should use a copy of your pictures to try it !!!!!

put your images in lfw_funneled folder(it's in lfw_home folder) first, then run Svm.py 