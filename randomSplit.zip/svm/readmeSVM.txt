this code will change the original size of you pictues,you should use a copy of your pictures to try it !!!!!
this code will change the original size of you pictues,you should use a copy of your pictures to try it !!!!!
this code will change the original size of you pictues,you should use a copy of your pictures to try it !!!!!

put your images in lfw_funneled folder(it's in lfw_home folder) first, then run Svm.py 
Everytime you run Svm.py， it will creat few files in _fetch_lfw_people folder(.\svm\lfw_home\joblib\sklearn\datasets\_lfw\_fetch_lfw_people),
you need to delete these files, then you can try other data sets.