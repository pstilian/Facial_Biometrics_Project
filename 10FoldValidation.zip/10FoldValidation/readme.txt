this code will change the original size of you pictues,you should use a copy of your pictures to try it !!!!!
this code will change the original size of you pictues,you should use a copy of your pictures to try it !!!!!
this code will change the original size of you pictues,you should use a copy of your pictures to try it !!!!!

put your pictures in data file folder and run FaceCapture.py first, then 
run training.py.The accuracy will be showen after you run training.py. 

Everytime you run training.py， it will creat __pycache__ folder, clf.pkl and feature_extractor.pkl,you need
 to delete these files, then you can try other data sets.