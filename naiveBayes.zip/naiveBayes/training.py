import numpy as np
import pickle
import math
from data_reader import DataReader
from feature_extractor import FeatureExtractor
#from sklearn.naive_bayes import GaussianNB
from sklearn.naive_bayes import GaussianNB, MultinomialNB,BernoulliNB
from sklearn.naive_bayes import GaussianNB, MultinomialNB,BernoulliNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.datasets import load_wine
from sklearn.naive_bayes import MultinomialNB
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.neural_network import MLPClassifier
from sklearn import svm


def main():
    data_reader = DataReader()  # reads the images files and converts them into numpy 2D arrays
    feature_extractor = FeatureExtractor()  # calculates the eigenfaces. Follows the fit->transform paradigm.
    #clf = GaussianNB()  # a naive bayes classifier where the individual variables are supposed to follow a gaussian distribution
    clf = BernoulliNB()

    # since the number of images available is relatively low (400 images),
    # we'll use cross-validation to assess the performance of the face recognition system.
    data = data_reader.getAllData(shuffle=True)  # we shuffle the data so we can do Cross-Validation
    num_folds = 10
    #print (data[0])

    fold_length = math.floor(len(data[0]) / num_folds)
    average_accuracy = 0.0  # the performance measure of the system

    for k in range(num_folds):
        # get train data and test data from data
        train_data, test_data = [None, None], [None, None]
        for i in range(2):
            if k == num_folds - 1:
                train_data[i] = data[i][:k * fold_length]
                test_data[i] = data[i][k * fold_length:]

            else:
                train_data[i] = data[i][:k * fold_length] + data[i][(k + 1) * fold_length:]
                test_data[i] = data[i][k * fold_length:(k + 1) * fold_length]
        train_data, test_data = tuple(train_data), tuple(test_data)

        # compute the eigenfaces and prepare the training data to train the classifier
        X_train = feature_extractor.fit_transform(train_data[0])  # computes eigenfaces and prepares training data
        y_train = np.array(train_data[1])  # prepares training labels
        clf.fit(X_train, y_train)  # trains the classifier

        # test the performance (accurancy) of the classifier on the current fold
        X_test = feature_extractor.transform(test_data[0])  # prepares the test data
        y_test = np.array(test_data[1])  # prepares the test labels
        average_accuracy += clf.score(X_test, y_test)  # accumulates the accuracies on each fold, we'll divide it by the number of folds later

    average_accuracy /= num_folds  # computes the average accuracy of the classifier over all the folds

    print('Average accuracy: {0}%'.format(round(100 * average_accuracy), 2))


    # save the classifier and the eigenfaces model for direct use via the main.py script
    # save the classifier
    f = open('clf.pkl', 'wb')
    pickle.dump(clf, f)
    f.close()

    # save the eigenfaces model
    f = open('feature_extractor.pkl', 'wb')
    pickle.dump(feature_extractor, f)
    f.close()

def retry():
    try:
        main()
        return
    except Exception as e:
        retry()
        
retry()