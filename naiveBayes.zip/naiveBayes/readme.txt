this code will change the original size of you pictues,you should use a copy of your pictures to try it !!!!!
this code will change the original size of you pictues,you should use a copy of your pictures to try it !!!!!
this code will change the original size of you pictues,you should use a copy of your pictures to try it !!!!!

put your pictures in data file and run FaceCapture.py first, then 
run training.py.The accuracy will be showen after you run training.py. 

The main.py is used for manual sampling inspection, it's not necessary for our project, and there are 
somebugs that I haven't correct in main.py. 