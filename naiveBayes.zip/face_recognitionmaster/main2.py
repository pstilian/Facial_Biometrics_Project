import sys
import pickle
import os
from data_reader import DataReader


# if the user didn't specify exactly one image path, we exit the program

    

if __name__=="__main__":
    #子文件夹
    for childPATH in os.listdir('Test'): #os.listdir() 方法用于返回指定的文件夹包含的文件或文件夹的名字的列表
        childPATH = 'Test' + '/'+ str(childPATH)
        print(childPATH)
        fileList = os.listdir(childPATH)
        print(fileList)
        print (len(fileList))
        currentpath = os.getcwd()  
        os.chdir(childPATH)
        for file in fileList: 
    
            #python ConcatenateFiles.py /tmp
            file = str(file)
            print(file)
            # read the image
            #image_path = sys.argv[1]
            #image_path = os.path.realpath(file) 
            os.path.realpath(file)
            
            if len(sys.argv) != 2:
                print('1 argument expected, found {0}'.format(len(sys.argv) - 1))
                exit()
            image_path = sys.argv[1]
            #image_path = sys.argv[1]
            print(image_path)
            data_reader = DataReader()
            img = data_reader.read(image_path)


    # feature extraction
    # load the feature extractor
    f = open('feature_extractor.pkl', 'rb')
    feature_extractor = pickle.load(f)
    f.close()

    # extract the features from the image
    X = feature_extractor.transform([img])


    # image classification
    # load the trained classifier
    f = open('clf.pkl', 'rb')
    clf = pickle.load(f)
    f.close()

    # predict the class (person)
    y = clf.predict(X)[0]

    # show the prediction
    print('y = {0}'.format(y))
    res = data_reader.read('data/s{0}/1.pgm'.format(y))
    img.show()
    res.show()