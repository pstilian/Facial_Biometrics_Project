# -*- coding: utf-8 -*-
"""
Created on Tue Oct 19 20:13:45 2021

@author: 30510
"""


import pandas
from sklearn import VarianceThreshold 
from sklearn import SVC 
from sklearn import Accuracy_score 
from sklearn import Train_test_split 
import numpy as np

