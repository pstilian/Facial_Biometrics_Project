# -*- coding: utf-8 -*-
"""
Created on Sun Oct 17 17:46:17 2021

@author: 30510
"""


from PIL import Image
import os
import cv2

path = 'F:\\MobileBiometrics\\GuideLearning2\\add'
pgm_path = '‪F:\\MobileBiometrics\\GuideLearning2\\adc'
# for item in os.walk(path):
#     print(item,end='/n')
filenames = os.listdir(path)
i=1
for filename in filenames:
    # print(filename)
    ioread = os.path.join(path,filename)
    print(ioread)
    print(pgm_path+'\pos-%d.pgm'%i)
    Image.open(ioread).convert('L').save(pgm_path.strip('\u202a') +'\%d.pgm'%i)
    i+=1