# -*- coding: utf-8 -*-
"""
Created on Mon Oct 25 16:12:34 2021

@author: 30510
"""


import cv2
import dlib

# 读取文件
image = '1.jpg'
image = cv2.imread(image)
image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

# 人脸检测
model = dlib.cnn_face_detection_model_v1('mmod_human_face_detector.dat')  # 加载模型
faces = model(image_rgb, 1)
for face in faces:
    face = face.rect
    (x, y, w, h) = face.left(), face.top(), face.right(), face.bottom()
    cv2.rectangle(image, (x, y), (w, h), (0, 255, 0), thickness=2)  # 画出人脸矩形框

# 显示和保存图片
cv2.imshow('result', image)
cv2.waitKey(0)
cv2.destroyAllWindows()
cv2.imwrite('result.jpg', image)
print('已保存')
